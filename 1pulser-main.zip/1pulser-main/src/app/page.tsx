import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import SocialProof from "@/components/SocialProof";
import Problems from "@/components/Problems";
import Offers from "@/components/Offers";
import Method from "@/components/Method";
import Results from "@/components/Results";
import CTABanner from "@/components/CTABanner";
import About from "@/components/About";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main className="overflow-x-hidden">
      <Navbar />
      <Hero />
      <SocialProof />
      <Problems />
      <Offers />
      <Method />
      <Results />
      <CTABanner />
      <About />
      <Contact />
      <Footer />
    </main>
  );
}
