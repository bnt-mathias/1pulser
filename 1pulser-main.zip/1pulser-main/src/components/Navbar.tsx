"use client";

import { useState, useEffect } from "react";
import { Menu, X, Phone } from "lucide-react";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const links = [
    { href: "#offres", label: "Offres" },
    { href: "#methode", label: "Méthode" },
    { href: "#resultats", label: "Résultats" },
    { href: "#apropos", label: "À propos" },
    { href: "#contact", label: "Contact" },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-white/95 backdrop-blur-sm shadow-sm border-b border-gray-100"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        {/* Logo */}
        <a href="#" className="flex items-center gap-2 group">
          <div className="w-9 h-9 bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg flex items-center justify-center shadow-md group-hover:shadow-orange-200 transition-shadow">
            <span className="text-white font-bold text-sm">1P</span>
          </div>
          <span
            className={`text-xl font-bold transition-colors ${scrolled ? "text-gray-900" : "text-white"}`}
          >
            1&apos;Pulser
          </span>
        </a>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-8">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className={`text-sm font-medium transition-colors hover:text-orange-500 ${
                scrolled ? "text-gray-700" : "text-white/90"
              }`}
            >
              {l.label}
            </a>
          ))}
        </nav>

        {/* CTA */}
        <div className="hidden md:flex items-center gap-3">
          <a
            href="tel:+33600000000"
            className={`flex items-center gap-1.5 text-sm font-medium transition-colors ${
              scrolled ? "text-gray-600 hover:text-orange-500" : "text-white/80 hover:text-white"
            }`}
          >
            <Phone size={14} />
            <span>06 00 00 00 00</span>
          </a>
          <a
            href="#contact"
            className="bg-orange-500 hover:bg-orange-600 text-white text-sm font-semibold px-5 py-2.5 rounded-lg transition-all hover:shadow-md hover:shadow-orange-200 hover:-translate-y-0.5"
          >
            Prendre rendez-vous
          </a>
        </div>

        {/* Mobile toggle */}
        <button
          className={`md:hidden p-2 rounded-lg ${scrolled ? "text-gray-700" : "text-white"}`}
          onClick={() => setIsOpen(!isOpen)}
          aria-label="Menu"
        >
          {isOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 shadow-lg">
          <div className="px-6 py-4 flex flex-col gap-4">
            {links.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="text-gray-700 font-medium hover:text-orange-500 transition-colors"
                onClick={() => setIsOpen(false)}
              >
                {l.label}
              </a>
            ))}
            <a
              href="#contact"
              className="bg-orange-500 text-white text-center font-semibold py-3 rounded-lg hover:bg-orange-600 transition-colors mt-2"
              onClick={() => setIsOpen(false)}
            >
              Prendre rendez-vous
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
