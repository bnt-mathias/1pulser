"use client";

import { Lightbulb, GraduationCap, Handshake, ArrowRight, Check } from "lucide-react";

const offers = [
  {
    icon: Lightbulb,
    tag: "Conseil",
    title: "Conseil Stratégique",
    desc: "Construisons ensemble votre stratégie commerciale sur mesure : positionnement, cibles, offres, canaux d'acquisition. Une feuille de route claire pour des actions concrètes.",
    points: [
      "Audit de votre démarche commerciale",
      "Définition de votre stratégie",
      "Plan d'action priorisé",
      "Suivi et ajustements",
    ],
    accent: "orange",
    featured: false,
  },
  {
    icon: GraduationCap,
    tag: "Formation",
    title: "Formation Commerciale",
    desc: "Des formations actionnables pour vous et vos équipes. Techniques de vente éthiques, gestion de la relation client, prospection efficace — du concret, pas du théorique.",
    points: [
      "Formats individuels ou collectifs",
      "Cas pratiques de votre secteur",
      "Outils et méthodes directement applicables",
      "Suivi post-formation",
    ],
    accent: "blue",
    featured: true,
  },
  {
    icon: Handshake,
    tag: "Accompagnement",
    title: "Accompagnement Opérationnel",
    desc: "Je travaille à vos côtés, dans le terrain. Mise en place des processus, animation des équipes, pilotage commercial — du résultat, pas des PowerPoints.",
    points: [
      "Présence terrain régulière",
      "Mise en place des outils",
      "Animation et montée en compétences",
      "Reporting et pilotage",
    ],
    accent: "orange",
    featured: false,
  },
];

export default function Offers() {
  return (
    <section id="offres" className="py-24 bg-gray-50">
      <div className="max-w-6xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 text-orange-500 text-sm font-semibold uppercase tracking-wider mb-4">
            <div className="w-8 h-px bg-orange-500" />
            Nos offres
            <div className="w-8 h-px bg-orange-500" />
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Des solutions adaptées à{" "}
            <span className="text-orange-500">vos enjeux</span>
          </h2>
          <p className="text-gray-500 text-lg max-w-2xl mx-auto">
            Que vous ayez besoin d&apos;une stratégie, d&apos;une montée en compétences ou
            d&apos;un soutien opérationnel, nous avons l&apos;offre qu&apos;il vous faut.
          </p>
        </div>

        {/* Offer cards */}
        <div className="grid md:grid-cols-3 gap-8">
          {offers.map((o) => {
            const Icon = o.icon;
            const isBlue = o.accent === "blue";
            return (
              <div
                key={o.title}
                className={`relative rounded-2xl p-8 flex flex-col transition-all duration-300 hover:-translate-y-2 ${
                  o.featured
                    ? "bg-blue-950 text-white shadow-2xl shadow-blue-900/30 ring-2 ring-orange-400"
                    : "bg-white text-gray-900 shadow-md hover:shadow-xl"
                }`}
              >
                {o.featured && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-orange-500 text-white text-xs font-bold px-4 py-1 rounded-full uppercase tracking-wider">
                    Le plus populaire
                  </div>
                )}
                {/* Icon */}
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center mb-6 ${
                    o.featured
                      ? "bg-orange-500/20 text-orange-400"
                      : "bg-orange-100 text-orange-500"
                  }`}
                >
                  <Icon size={22} />
                </div>

                <div
                  className={`text-xs font-bold uppercase tracking-wider mb-2 ${
                    o.featured ? "text-orange-400" : "text-orange-500"
                  }`}
                >
                  {o.tag}
                </div>
                <h3
                  className={`text-xl font-bold mb-4 ${
                    o.featured ? "text-white" : "text-gray-900"
                  }`}
                >
                  {o.title}
                </h3>
                <p
                  className={`leading-relaxed mb-6 text-sm ${
                    o.featured ? "text-blue-200/80" : "text-gray-600"
                  }`}
                >
                  {o.desc}
                </p>

                <ul className="flex flex-col gap-3 mb-8 flex-1">
                  {o.points.map((pt) => (
                    <li key={pt} className="flex items-start gap-2.5">
                      <Check
                        size={15}
                        className={`mt-0.5 flex-shrink-0 ${
                          o.featured ? "text-orange-400" : "text-orange-500"
                        }`}
                      />
                      <span
                        className={`text-sm ${
                          o.featured ? "text-blue-100/80" : "text-gray-600"
                        }`}
                      >
                        {pt}
                      </span>
                    </li>
                  ))}
                </ul>

                <a
                  href="#contact"
                  className={`flex items-center justify-center gap-2 py-3 px-6 rounded-xl font-semibold text-sm transition-all group ${
                    o.featured
                      ? "bg-orange-500 hover:bg-orange-600 text-white hover:shadow-lg hover:shadow-orange-500/30"
                      : "border-2 border-orange-500 text-orange-500 hover:bg-orange-500 hover:text-white"
                  }`}
                >
                  En savoir plus
                  <ArrowRight
                    size={15}
                    className="group-hover:translate-x-0.5 transition-transform"
                  />
                </a>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
