"use client";

import { Phone, Mail, Linkedin, ArrowUpRight } from "lucide-react";

const links = {
  site: [
    { href: "#offres", label: "Nos offres" },
    { href: "#methode", label: "Notre méthode" },
    { href: "#resultats", label: "Résultats" },
    { href: "#apropos", label: "À propos" },
    { href: "#contact", label: "Contact" },
  ],
  offres: [
    { href: "#offres", label: "Conseil stratégique" },
    { href: "#offres", label: "Formation commerciale" },
    { href: "#offres", label: "Accompagnement opérationnel" },
    { href: "#contact", label: "Appel gratuit 30 min" },
  ],
};

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-white">
      {/* Top section */}
      <div className="max-w-6xl mx-auto px-6 py-16 grid md:grid-cols-4 gap-10">
        {/* Brand */}
        <div className="md:col-span-1">
          <div className="flex items-center gap-2 mb-5">
            <div className="w-9 h-9 bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">1P</span>
            </div>
            <span className="text-xl font-bold">1&apos;Pulser</span>
          </div>
          <p className="text-blue-200/60 text-sm leading-relaxed mb-6">
            Conseil et formation en développement commercial durable pour
            dirigeants de PME.
          </p>
          <div className="space-y-2">
            <a
              href="tel:+33600000000"
              className="flex items-center gap-2 text-blue-200/60 hover:text-orange-400 text-sm transition-colors"
            >
              <Phone size={14} />
              06 00 00 00 00
            </a>
            <a
              href="mailto:contact@1pulser.fr"
              className="flex items-center gap-2 text-blue-200/60 hover:text-orange-400 text-sm transition-colors"
            >
              <Mail size={14} />
              contact@1pulser.fr
            </a>
          </div>
        </div>

        {/* Site links */}
        <div>
          <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">
            Navigation
          </h4>
          <ul className="space-y-2.5">
            {links.site.map((l) => (
              <li key={l.href + l.label}>
                <a
                  href={l.href}
                  className="text-blue-200/60 hover:text-white text-sm transition-colors"
                >
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        {/* Offers */}
        <div>
          <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">
            Nos offres
          </h4>
          <ul className="space-y-2.5">
            {links.offres.map((l) => (
              <li key={l.label}>
                <a
                  href={l.href}
                  className="text-blue-200/60 hover:text-white text-sm transition-colors"
                >
                  {l.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        {/* CTA box */}
        <div>
          <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">
            Agissez maintenant
          </h4>
          <div className="bg-white/5 border border-white/10 rounded-2xl p-5">
            <p className="text-blue-200/60 text-sm mb-4 leading-relaxed">
              Échangeons gratuitement sur votre situation commerciale.
            </p>
            <a
              href="#contact"
              className="flex items-center justify-between bg-orange-500 hover:bg-orange-600 text-white text-sm font-semibold px-4 py-3 rounded-xl transition-colors group"
            >
              Réserver un appel gratuit
              <ArrowUpRight
                size={14}
                className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform"
              />
            </a>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/10">
        <div className="max-w-6xl mx-auto px-6 py-6 flex flex-col md:flex-row items-center justify-between gap-4 text-blue-200/40 text-sm">
          <p>© 2024 1&apos;Pulser — Tous droits réservés</p>
          <div className="flex items-center gap-4">
            <span>
              Mots-clés : développement commercial · formation commerciale ·
              stratégie PME
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
