"use client";

import { Calendar, Clock, CheckCircle } from "lucide-react";

export default function CTABanner() {
  return (
    <section className="py-24 bg-gradient-to-br from-blue-950 via-slate-900 to-blue-950 relative overflow-hidden">
      {/* Decorative */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-px bg-gradient-to-r from-transparent via-orange-500/50 to-transparent" />
      <div className="absolute top-1/2 left-0 -translate-y-1/2 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl" />
      <div className="absolute top-1/2 right-0 -translate-y-1/2 w-96 h-96 bg-blue-400/10 rounded-full blur-3xl" />

      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 bg-orange-500/20 border border-orange-500/30 text-orange-300 text-sm font-medium px-4 py-2 rounded-full mb-8">
          <span className="w-1.5 h-1.5 bg-orange-400 rounded-full animate-pulse" />
          Offre gratuite, sans engagement
        </div>

        <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 leading-tight">
          Réservez un appel gratuit{" "}
          <span className="text-orange-400">de 30 minutes</span>
        </h2>
        <p className="text-blue-200/70 text-xl mb-10 max-w-2xl mx-auto leading-relaxed">
          Échangeons sur votre situation commerciale et identifions ensemble les
          leviers de croissance les plus rapides pour votre entreprise.
        </p>

        {/* Reassurances */}
        <div className="flex flex-wrap justify-center gap-6 mb-10">
          {[
            { icon: Clock, text: "30 min chrono, sans blabla" },
            { icon: CheckCircle, text: "100% gratuit, sans engagement" },
            { icon: Calendar, text: "Disponible sous 48h" },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.text}
                className="flex items-center gap-2 text-blue-200/80 text-sm"
              >
                <Icon size={15} className="text-orange-400" />
                {item.text}
              </div>
            );
          })}
        </div>

        {/* CTA */}
        <a
          href="#contact"
          className="group inline-flex items-center gap-3 bg-orange-500 hover:bg-orange-600 text-white font-bold px-10 py-5 rounded-2xl text-lg transition-all hover:shadow-2xl hover:shadow-orange-500/40 hover:-translate-y-1"
        >
          <Calendar size={22} />
          Je réserve mon appel gratuit
          <span className="text-orange-200 text-sm font-normal">→</span>
        </a>

        <p className="text-blue-200/40 text-sm mt-6">
          Ou appelez directement :{" "}
          <a
            href="tel:+33600000000"
            className="text-blue-200/60 hover:text-white transition-colors underline"
          >
            06 00 00 00 00
          </a>
        </p>
      </div>
    </section>
  );
}
