"use client";

import { useState } from "react";
import { Phone, Mail, MapPin, Send, CheckCircle } from "lucide-react";

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    message: "",
    subject: "conseil",
  });

  const handleChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    setTimeout(() => setSubmitted(true), 500);
  };

  return (
    <section id="contact" className="py-24 bg-gray-50">
      <div className="max-w-6xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 text-orange-500 text-sm font-semibold uppercase tracking-wider mb-4">
            <div className="w-8 h-px bg-orange-500" />
            Contact
            <div className="w-8 h-px bg-orange-500" />
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Parlons de votre développement commercial
          </h2>
          <p className="text-gray-500 text-lg max-w-2xl mx-auto">
            Une question, un projet, envie d&apos;échanger ? Contactez-nous et nous
            vous répondrons sous 24h.
          </p>
        </div>

        <div className="grid lg:grid-cols-5 gap-12">
          {/* Left: Info */}
          <div className="lg:col-span-2 space-y-8">
            <div>
              <h3 className="text-xl font-bold text-gray-900 mb-6">
                Nos coordonnées
              </h3>
              <div className="space-y-4">
                {[
                  {
                    icon: Phone,
                    label: "Téléphone",
                    value: "06 00 00 00 00",
                    href: "tel:+33600000000",
                  },
                  {
                    icon: Mail,
                    label: "Email",
                    value: "contact@1pulser.fr",
                    href: "mailto:contact@1pulser.fr",
                  },
                  {
                    icon: MapPin,
                    label: "Zone d'intervention",
                    value: "France entière (présentiel & distanciel)",
                    href: null,
                  },
                ].map((item) => {
                  const Icon = item.icon;
                  return (
                    <div key={item.label} className="flex items-start gap-4">
                      <div className="w-10 h-10 bg-orange-100 text-orange-500 rounded-xl flex items-center justify-center flex-shrink-0">
                        <Icon size={18} />
                      </div>
                      <div>
                        <div className="text-xs text-gray-400 font-medium uppercase tracking-wide mb-0.5">
                          {item.label}
                        </div>
                        {item.href ? (
                          <a
                            href={item.href}
                            className="text-gray-900 font-medium hover:text-orange-500 transition-colors"
                          >
                            {item.value}
                          </a>
                        ) : (
                          <span className="text-gray-700 font-medium">
                            {item.value}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Direct CTA */}
            <div className="bg-gradient-to-br from-slate-900 to-blue-950 rounded-2xl p-7 text-white">
              <div className="text-orange-400 text-sm font-semibold uppercase tracking-wider mb-3">
                Réponse rapide garantie
              </div>
              <h4 className="text-xl font-bold mb-3">
                Appelez directement
              </h4>
              <p className="text-blue-200/60 text-sm mb-5 leading-relaxed">
                Préférez le téléphone ? Appelez-nous pour un premier échange
                sans engagement.
              </p>
              <a
                href="tel:+33600000000"
                className="flex items-center justify-center gap-2 bg-orange-500 hover:bg-orange-600 text-white font-semibold py-3 px-6 rounded-xl transition-all hover:shadow-lg hover:shadow-orange-500/20"
              >
                <Phone size={16} />
                06 00 00 00 00
              </a>
            </div>

            {/* Hours */}
            <div className="text-sm text-gray-500">
              <span className="font-medium text-gray-700">Disponibilité :</span>{" "}
              Lundi – Vendredi, 9h – 18h
            </div>
          </div>

          {/* Right: Form */}
          <div className="lg:col-span-3">
            {submitted ? (
              <div className="bg-white rounded-2xl p-12 shadow-sm flex flex-col items-center justify-center text-center h-full min-h-[400px]">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
                  <CheckCircle size={32} className="text-green-500" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-3">
                  Message envoyé !
                </h3>
                <p className="text-gray-500 max-w-sm">
                  Merci pour votre message. Nous vous répondrons dans les plus
                  brefs délais, sous 24h maximum.
                </p>
              </div>
            ) : (
              <form
                onSubmit={handleSubmit}
                className="bg-white rounded-2xl p-8 shadow-sm"
              >
                <div className="grid md:grid-cols-2 gap-5 mb-5">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">
                      Nom & Prénom *
                    </label>
                    <input
                      type="text"
                      name="name"
                      required
                      value={form.name}
                      onChange={handleChange}
                      placeholder="Jean Dupont"
                      className="w-full border border-gray-200 rounded-xl px-4 py-3 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">
                      Email *
                    </label>
                    <input
                      type="email"
                      name="email"
                      required
                      value={form.email}
                      onChange={handleChange}
                      placeholder="jean@entreprise.fr"
                      className="w-full border border-gray-200 rounded-xl px-4 py-3 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">
                      Téléphone
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={form.phone}
                      onChange={handleChange}
                      placeholder="06 00 00 00 00"
                      className="w-full border border-gray-200 rounded-xl px-4 py-3 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1.5">
                      Entreprise
                    </label>
                    <input
                      type="text"
                      name="company"
                      value={form.company}
                      onChange={handleChange}
                      placeholder="Ma PME"
                      className="w-full border border-gray-200 rounded-xl px-4 py-3 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500 transition-colors"
                    />
                  </div>
                </div>

                <div className="mb-5">
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">
                    Sujet
                  </label>
                  <select
                    name="subject"
                    value={form.subject}
                    onChange={handleChange}
                    className="w-full border border-gray-200 rounded-xl px-4 py-3 text-gray-900 focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500 transition-colors bg-white"
                  >
                    <option value="conseil">Conseil stratégique</option>
                    <option value="formation">Formation commerciale</option>
                    <option value="accompagnement">Accompagnement opérationnel</option>
                    <option value="rdv">Réserver un appel gratuit</option>
                    <option value="autre">Autre</option>
                  </select>
                </div>

                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">
                    Votre message *
                  </label>
                  <textarea
                    name="message"
                    required
                    value={form.message}
                    onChange={handleChange}
                    rows={5}
                    placeholder="Décrivez votre situation, vos enjeux, vos questions..."
                    className="w-full border border-gray-200 rounded-xl px-4 py-3 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-orange-500/30 focus:border-orange-500 transition-colors resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-2 bg-orange-500 hover:bg-orange-600 text-white font-semibold py-4 rounded-xl transition-all hover:shadow-lg hover:shadow-orange-200 hover:-translate-y-0.5 text-lg"
                >
                  <Send size={18} />
                  Envoyer mon message
                </button>

                <p className="text-center text-xs text-gray-400 mt-4">
                  Réponse sous 24h • Données confidentielles
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
