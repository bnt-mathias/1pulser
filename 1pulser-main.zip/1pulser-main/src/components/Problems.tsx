"use client";

import { Users, Clock, BarChart2, Target } from "lucide-react";

const problems = [
  {
    icon: Users,
    title: "Difficile de trouver des clients",
    desc: "Vous faites du réseau, vous prospectez, mais les résultats ne sont pas au rendez-vous. La croissance stagne et vous ne savez plus par où commencer.",
    color: "text-red-500",
    bg: "bg-red-50",
  },
  {
    icon: Clock,
    title: "Trop de temps perdu",
    desc: "Votre agenda déborde d'actions commerciales peu productives. Vous courez dans tous les sens sans avoir l'impression d'avancer vraiment.",
    color: "text-amber-500",
    bg: "bg-amber-50",
  },
  {
    icon: BarChart2,
    title: "Manque d'organisation commerciale",
    desc: "Pas de processus clair, pas de suivi rigoureux. Chaque mois ressemble à une improvisation et la prévisibilité est inexistante.",
    color: "text-orange-500",
    bg: "bg-orange-50",
  },
  {
    icon: Target,
    title: "Des efforts sans résultats",
    desc: "Vous travaillez dur, vous essayez différentes approches, mais le chiffre d'affaires ne décolle pas. La frustration s'accumule.",
    color: "text-purple-500",
    bg: "bg-purple-50",
  },
];

export default function Problems() {
  return (
    <section className="py-24 bg-slate-900 relative overflow-hidden">
      {/* Decorative */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-orange-500/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl" />

      <div className="relative z-10 max-w-6xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 text-orange-400 text-sm font-semibold uppercase tracking-wider mb-4">
            <div className="w-8 h-px bg-orange-400" />
            Vous vous reconnaissez ?
            <div className="w-8 h-px bg-orange-400" />
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ces problèmes vous empêchent{" "}
            <span className="text-orange-400">de grandir</span>
          </h2>
          <p className="text-blue-200/70 text-lg max-w-2xl mx-auto">
            De nombreux dirigeants vivent ces situations au quotidien. La bonne
            nouvelle : elles ont toutes des solutions concrètes.
          </p>
        </div>

        {/* Problem cards */}
        <div className="grid md:grid-cols-2 gap-6">
          {problems.map((p) => {
            const Icon = p.icon;
            return (
              <div
                key={p.title}
                className="bg-white/5 border border-white/10 rounded-2xl p-8 hover:bg-white/10 hover:border-white/20 transition-all duration-300 group"
              >
                <div
                  className={`w-12 h-12 ${p.bg} ${p.color} rounded-xl flex items-center justify-center mb-5 group-hover:scale-110 transition-transform`}
                >
                  <Icon size={22} />
                </div>
                <h3 className="text-white text-xl font-semibold mb-3">
                  {p.title}
                </h3>
                <p className="text-blue-200/60 leading-relaxed">{p.desc}</p>
              </div>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <p className="text-blue-200/60 mb-6">
            Vous n&apos;avez pas à continuer comme ça.
          </p>
          <a
            href="#offres"
            className="inline-flex items-center gap-2 bg-orange-500 hover:bg-orange-600 text-white font-semibold px-8 py-4 rounded-xl transition-all hover:shadow-2xl hover:shadow-orange-500/20 hover:-translate-y-0.5"
          >
            Voir comment on peut vous aider
          </a>
        </div>
      </div>
    </section>
  );
}
