"use client";

import { Users, ShoppingBag, LayoutGrid, Smile } from "lucide-react";

const results = [
  {
    icon: Users,
    stat: "+40%",
    title: "Plus de clients",
    desc: "Nos clients constatent en moyenne une augmentation de 40% de leur base clients dans les 12 premiers mois.",
    color: "bg-orange-500",
  },
  {
    icon: ShoppingBag,
    stat: "+35%",
    title: "Plus de commandes",
    desc: "Augmentation du nombre de commandes grâce à une relation client plus forte et un parcours d'achat optimisé.",
    color: "bg-blue-600",
  },
  {
    icon: LayoutGrid,
    stat: "×3",
    title: "Meilleure organisation",
    desc: "Un processus commercial structuré réduit le temps perdu et multiplie l'efficacité des actions de vente.",
    color: "bg-teal-500",
  },
  {
    icon: Smile,
    stat: "100%",
    title: "Sérénité commerciale",
    desc: "Un cadre commercial clair, des objectifs atteignables, une équipe motivée. Le plaisir de vendre, retrouvé.",
    color: "bg-purple-500",
  },
];

export default function Results() {
  return (
    <section id="resultats" className="py-24 bg-gray-50">
      <div className="max-w-6xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 text-orange-500 text-sm font-semibold uppercase tracking-wider mb-4">
            <div className="w-8 h-px bg-orange-500" />
            Résultats
            <div className="w-8 h-px bg-orange-500" />
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Ce que vous obtenez concrètement
          </h2>
          <p className="text-gray-500 text-lg max-w-2xl mx-auto">
            Des résultats mesurables, durables et alignés avec vos valeurs. Pas
            de promesses irréalistes, mais des transformations profondes.
          </p>
        </div>

        {/* Result cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {results.map((r) => {
            const Icon = r.icon;
            return (
              <div
                key={r.title}
                className="bg-white rounded-2xl p-8 text-center shadow-sm hover:shadow-xl hover:-translate-y-2 transition-all duration-300 group"
              >
                <div
                  className={`w-14 h-14 ${r.color} rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform shadow-md`}
                >
                  <Icon size={24} className="text-white" />
                </div>
                <div className="text-4xl font-black text-gray-900 mb-2">
                  {r.stat}
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-3">
                  {r.title}
                </h3>
                <p className="text-gray-500 text-sm leading-relaxed">{r.desc}</p>
              </div>
            );
          })}
        </div>

        {/* Visual banner */}
        <div className="mt-16 rounded-3xl bg-gradient-to-r from-orange-500 to-orange-600 p-10 md:p-14 text-white text-center relative overflow-hidden">
          <div className="absolute inset-0 opacity-10" style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='30' height='30' viewBox='0 0 30 30' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Ccircle cx='15' cy='15' r='2'/%3E%3C/g%3E%3C/svg%3E")`
          }} />
          <div className="relative z-10">
            <h3 className="text-2xl md:text-3xl font-bold mb-4">
              Et si c&apos;était votre tour ?
            </h3>
            <p className="text-white/80 mb-8 text-lg max-w-xl mx-auto">
              Rejoignez les dirigeants qui ont transformé leur développement
              commercial avec 1&apos;Pulser.
            </p>
            <a
              href="#contact"
              className="inline-flex items-center gap-2 bg-white text-orange-600 font-bold px-8 py-4 rounded-xl hover:bg-orange-50 transition-all hover:shadow-xl hover:-translate-y-1 text-lg"
            >
              Réservez votre appel gratuit de 30 min
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
