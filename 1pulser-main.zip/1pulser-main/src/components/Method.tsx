"use client";

import { Heart, TrendingUp, Leaf } from "lucide-react";

const pillars = [
  {
    icon: Heart,
    number: "01",
    title: "Humain avant tout",
    desc: "Nous croyons que la vente, c'est avant tout une relation de confiance. Notre approche repose sur l'authenticité, l'écoute profonde et la création de valeur réelle pour votre client.",
    color: "from-orange-500 to-red-500",
  },
  {
    icon: TrendingUp,
    number: "02",
    title: "Performance économique durable",
    desc: "Pas de croissance à tout prix qui s'effondre après 6 mois. Nous construisons avec vous un moteur commercial solide, régulier et prévisible qui tient dans le temps.",
    color: "from-blue-500 to-blue-700",
  },
  {
    icon: Leaf,
    number: "03",
    title: "Approche responsable",
    desc: "Le commerce éthique, c'est aussi une démarche durable. Respecter ses clients, ses équipes et ses valeurs. C'est notre conviction — et ça se traduit dans chaque accompagnement.",
    color: "from-green-500 to-teal-600",
  },
];

const steps = [
  { n: "1", title: "Diagnostic", desc: "Audit complet de votre situation commerciale actuelle" },
  { n: "2", title: "Stratégie", desc: "Définition d'une feuille de route personnalisée" },
  { n: "3", title: "Action", desc: "Mise en œuvre concrète et accompagnement terrain" },
  { n: "4", title: "Résultats", desc: "Mesure, ajustements et montée en puissance" },
];

export default function Method() {
  return (
    <section id="methode" className="py-24 bg-white">
      <div className="max-w-6xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 text-orange-500 text-sm font-semibold uppercase tracking-wider mb-4">
            <div className="w-8 h-px bg-orange-500" />
            Notre méthode
            <div className="w-8 h-px bg-orange-500" />
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            La commercialisation durable :{" "}
            <span className="text-orange-500">notre différence</span>
          </h2>
          <p className="text-gray-500 text-lg max-w-2xl mx-auto">
            Une approche fondée sur 3 piliers indissociables qui font la force
            et la pérennité de votre développement commercial.
          </p>
        </div>

        {/* 3 Pillars */}
        <div className="grid md:grid-cols-3 gap-8 mb-20">
          {pillars.map((p) => {
            const Icon = p.icon;
            return (
              <div
                key={p.title}
                className="group relative rounded-2xl overflow-hidden"
              >
                {/* Gradient top bar */}
                <div className={`h-1.5 w-full bg-gradient-to-r ${p.color}`} />
                <div className="p-8 bg-gray-50 hover:bg-white border border-gray-100 hover:shadow-xl transition-all duration-300 rounded-b-2xl h-full">
                  <div className="flex items-start gap-4 mb-4">
                    <div
                      className={`w-12 h-12 bg-gradient-to-br ${p.color} rounded-xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform shadow-md`}
                    >
                      <Icon size={22} className="text-white" />
                    </div>
                    <span className="text-4xl font-black text-gray-100 leading-none mt-1">
                      {p.number}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">
                    {p.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed text-sm">
                    {p.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Process steps */}
        <div className="bg-gradient-to-br from-slate-900 to-blue-950 rounded-3xl p-10 md:p-14">
          <h3 className="text-white text-2xl font-bold text-center mb-12">
            Notre processus en 4 étapes
          </h3>
          <div className="grid md:grid-cols-4 gap-8">
            {steps.map((s, idx) => (
              <div key={s.n} className="relative flex flex-col items-center text-center">
                {/* Connector line */}
                {idx < steps.length - 1 && (
                  <div className="hidden md:block absolute top-6 left-[calc(50%+28px)] right-0 h-px bg-white/20" />
                )}
                <div className="w-12 h-12 bg-orange-500 text-white font-bold text-lg rounded-full flex items-center justify-center mb-4 relative z-10 ring-4 ring-orange-500/20">
                  {s.n}
                </div>
                <h4 className="text-white font-semibold mb-2">{s.title}</h4>
                <p className="text-blue-200/60 text-sm">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
