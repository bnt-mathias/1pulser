"use client";

import { Award, Target, Heart, ArrowRight } from "lucide-react";

const values = [
  { icon: Award, label: "Excellence", desc: "Méthodes éprouvées, résultats mesurables" },
  { icon: Target, label: "Pragmatisme", desc: "Du concret, de l'actionnable, du résultat" },
  { icon: Heart, label: "Humanisme", desc: "Les relations au cœur de chaque action" },
];

export default function About() {
  return (
    <section id="apropos" className="py-24 bg-white">
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left: Image placeholder + decorative */}
          <div className="relative">
            <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-slate-900 to-blue-950 aspect-[4/5] max-w-sm mx-auto lg:mx-0">
              {/* Fake portrait */}
              <div className="absolute inset-0 flex flex-col items-center justify-center p-10">
                <div className="w-32 h-32 bg-orange-500/20 rounded-full flex items-center justify-center mb-6 ring-4 ring-orange-500/30">
                  <span className="text-5xl font-bold text-orange-400">JD</span>
                </div>
                <h3 className="text-white text-2xl font-bold mb-1">Jean Dupont</h3>
                <p className="text-orange-400 text-sm font-medium mb-4">Fondateur & Consultant</p>
                <div className="w-16 h-px bg-white/20 mb-4" />
                <p className="text-blue-200/60 text-sm text-center leading-relaxed">
                  15 ans de terrain en développement commercial B2B pour PME et ETI
                </p>
              </div>
              {/* Decorative dots */}
              <div className="absolute bottom-0 right-0 p-6">
                <div className="grid grid-cols-3 gap-1.5 opacity-30">
                  {Array.from({ length: 9 }).map((_, i) => (
                    <div key={i} className="w-1.5 h-1.5 bg-white rounded-full" />
                  ))}
                </div>
              </div>
            </div>
            {/* Stats badge */}
            <div className="absolute -bottom-6 -right-4 lg:right-auto lg:-left-6 bg-orange-500 text-white rounded-2xl p-5 shadow-2xl shadow-orange-500/30">
              <div className="text-3xl font-black">+15</div>
              <div className="text-white/80 text-xs font-medium">ans d&apos;expérience</div>
            </div>
          </div>

          {/* Right: Content */}
          <div className="pt-8 lg:pt-0">
            <div className="inline-flex items-center gap-2 text-orange-500 text-sm font-semibold uppercase tracking-wider mb-4">
              <div className="w-8 h-px bg-orange-500" />
              À propos
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Une vision claire du{" "}
              <span className="text-orange-500">commerce responsable</span>
            </h2>

            <div className="space-y-4 text-gray-600 leading-relaxed mb-8">
              <p>
                Après plus de 15 ans à accompagner des dirigeants de PME dans
                leur développement commercial, j&apos;ai une conviction profonde : on
                peut vendre plus{" "}
                <strong className="text-gray-900">sans perdre son âme</strong>.
              </p>
              <p>
                Trop souvent, les approches commerciales sont agressives,
                artificielles, ou déconnectées des vraies valeurs des
                entrepreneurs. J&apos;ai créé 1&apos;Pulser pour proposer une alternative.
              </p>
              <p>
                Ma mission : vous aider à construire une démarche commerciale{" "}
                <strong className="text-gray-900">
                  efficace, éthique et durable
                </strong>{" "}
                — qui génère des résultats ET vous permet de vous lever le matin
                avec enthousiasme.
              </p>
            </div>

            {/* Values */}
            <div className="grid grid-cols-3 gap-4 mb-10">
              {values.map((v) => {
                const Icon = v.icon;
                return (
                  <div key={v.label} className="text-center">
                    <div className="w-10 h-10 bg-orange-100 text-orange-500 rounded-xl flex items-center justify-center mx-auto mb-2">
                      <Icon size={18} />
                    </div>
                    <div className="font-semibold text-gray-900 text-sm mb-0.5">
                      {v.label}
                    </div>
                    <div className="text-gray-500 text-xs">{v.desc}</div>
                  </div>
                );
              })}
            </div>

            <a
              href="#contact"
              className="group inline-flex items-center gap-2 bg-orange-500 hover:bg-orange-600 text-white font-semibold px-8 py-4 rounded-xl transition-all hover:shadow-lg hover:shadow-orange-200 hover:-translate-y-0.5"
            >
              Parlons de votre projet
              <ArrowRight
                size={16}
                className="group-hover:translate-x-0.5 transition-transform"
              />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
