"use client";

import { Star, Quote } from "lucide-react";

const stats = [
  { value: "+15", label: "ans d'expérience", sub: "en développement commercial" },
  { value: "100+", label: "PME accompagnées", sub: "dirigeants et équipes commerciales" },
  { value: "93%", label: "taux de satisfaction", sub: "sur nos formations et accompagnements" },
  { value: "2,5×", label: "ROI moyen", sub: "constaté chez nos clients en 12 mois" },
];

const testimonials = [
  {
    name: "Marie-Claire Dupont",
    role: "Dirigeante, Cabinet RH Innovance",
    text: "Grâce à 1'Pulser, j'ai enfin une stratégie commerciale claire et cohérente. En 6 mois, mon CA a progressé de 40% sans courir après les prospects.",
    stars: 5,
  },
  {
    name: "Julien Marchal",
    role: "Co-fondateur, TechSolutions PME",
    text: "La méthode est concrète, humaine et efficace. L'accompagnement nous a permis de structurer notre démarche et de doubler notre portefeuille clients.",
    stars: 5,
  },
  {
    name: "Sophie Renard",
    role: "Responsable commerciale, BTP Services",
    text: "Je recommande vivement 1'Pulser à tous les dirigeants qui cherchent à développer leurs ventes sans perdre leur âme. Une approche unique et vraiment différenciante.",
    stars: 5,
  },
];

export default function SocialProof() {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-6xl mx-auto px-6">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-24">
          {stats.map((s) => (
            <div key={s.value} className="text-center group">
              <div className="text-4xl md:text-5xl font-bold text-orange-500 mb-1 group-hover:scale-105 transition-transform">
                {s.value}
              </div>
              <div className="font-semibold text-gray-900 mb-1">{s.label}</div>
              <div className="text-sm text-gray-500">{s.sub}</div>
            </div>
          ))}
        </div>

        {/* Section title */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 text-orange-500 text-sm font-semibold uppercase tracking-wider mb-4">
            <div className="w-8 h-px bg-orange-500" />
            Témoignages
            <div className="w-8 h-px bg-orange-500" />
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
            Ce que disent nos clients
          </h2>
        </div>

        {/* Testimonials */}
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((t) => (
            <div
              key={t.name}
              className="bg-gray-50 rounded-2xl p-8 relative hover:shadow-lg hover:-translate-y-1 transition-all duration-300"
            >
              <Quote
                size={32}
                className="text-orange-200 mb-4"
                fill="currentColor"
              />
              <p className="text-gray-700 leading-relaxed mb-6 italic">
                &ldquo;{t.text}&rdquo;
              </p>
              <div className="flex items-center gap-1 mb-4">
                {Array.from({ length: t.stars }).map((_, i) => (
                  <Star
                    key={i}
                    size={14}
                    className="text-orange-400 fill-orange-400"
                  />
                ))}
              </div>
              <div>
                <div className="font-semibold text-gray-900">{t.name}</div>
                <div className="text-sm text-gray-500">{t.role}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
